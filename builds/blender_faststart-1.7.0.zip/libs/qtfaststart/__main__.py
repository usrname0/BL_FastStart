from qtfaststart import command
command.run()
